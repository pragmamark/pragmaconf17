
# Core Data Performance

-----

Core Data implementation in many projects.

![inline fill](ratsnest.jpg)

[.footer: image from [Flicker](https://www.flickr.com/photos/editor/93142185)]

^I've worked on many projects who use Core Data or abandoned Core Data because of complexity and complications.
Don't make things more complicated than they need to be, start with the simplest thing.

-----

![inline fit](iphone3gs.jpg)

We're not building for this anymore.

^We aren't on the iPhone 3GS anymore, it's possible performance isn't an issue.
There was a time when we needed all kinds of tricks. Even running all your data through the JSON parser at once could be trouble.

----

Pinbook

![inline fit](pinbook.jpeg)

^My friend wrote an app for the once-popular pinboard who's API returned all your thousands of bookmarks in one shot.
He found customers with over 100k bookmarks!
Not only did he do streaming XML parsing to make things fast enough, but had to sink down to writing most of the work in C to get things
done in a reasonable amount of time.

-----

![inline](oneroom.png)

Most projects aren't a problem.

^Most projects don't need all that, especially on modern devices.
Simple case where only one context is used, no need for anything fancy.

-----

All hail the source of truth!

![inline](Apple_Instruments_Icon.png)

^One of the nicest things about developing on iOS is Instruments. We don't need to guess or speculate, we can tell exactly where our code is being slow.
Only make it more complicated when Instruments says you need to.

----

![inline](OneRoomFirstLoad.png)

^On first load, it doesn't spend enough time to care.

----

![inline](OneRoomRefresh.png)

^When reloading, it takes even less time.

----

![inline](1000RoomsFirstLoad.png)

^If there are 1000 items, time starts to be more noticeable, but not toooo terrible.

----

![inline](1000RoomsRefresh.png)

^When I refresh the list of 1000 items, they're all duplicates. Trouble!

----

![inline](5000RoomsRefresh.png)

^5000 items, a more extreme example.
Nearly enough time to have the watchdog terminate your app.

----

![inline](5000RoomsBackgrounded.png)

^Backgrounding the processing
Still takes a while, but now only half a second is spent on the main thread. Still enough to notice

----

![inline](5000RoomsRefreshDrillDown.png)

^If we drill down, we can see most of the time on the main thread is merging the changes from the background thread. Since every single object was updated.

----

![inline](5000RoomsBatchSaving.png)

^Saving every 100 items, makes for smaller changes to merge. Whole process takes less time and now only 1 second is spent on the main thread.
This is spread out also, so there's time in between to do UI updates.

----

![left 200%](Just Process.png)
![right 200%](BatchDelete.png)

^Surprisingly, deleting all the items in one big batch delete before processing the new entries actually makes things slower. Makes even more time spent on the main thread.
You can see on the left if we process like normal, 5000 items takes time.
On the right is if we batch delete first, less overall time, but more of it is spent on the main thread, again processing changes.

----

![inline](Only100Dupes.png)

^More realistically what you would want to do is have your API only give you info for the items which actually changed. If we pretend like there are only 100 items to update on refresh, we go back down to using a whole 25ms on the main thread.
Sometimes the best gains are had without changing your code at all.

----

For more information:

- [What's New In Core Data 2017](https://developer.apple.com/videos/play/wwdc2017/210/)
- [What's New In Core Data 2016](https://developer.apple.com/videos/play/wwdc2016/242/)
- [Instruments User Guide](https://developer.apple.com/library/content/documentation/DeveloperTools/Conceptual/InstrumentsUserGuide/index.html)
- [Using Time Profiler in Instruments](https://developer.apple.com/videos/play/wwdc2016/418/)

^Core Data is still changing, so I recommend keeping up by watching the latest WWDC videos.
Instruments itself is also changing, so older tutorials might be out of date, good to go straight to the source.

----

# Thank You!

![inline](roundwall_square.png)

@samuelgoodwin
samuel@roundwallsoftware.com
roundwallsoftware.com
