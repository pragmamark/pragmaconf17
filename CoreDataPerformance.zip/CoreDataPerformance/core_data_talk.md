# Core Data Performance

- Don't make things more complicated than they need to be, start with the simplest thing.
- Only make it more complicated when Instruments says you need to.

# Mark all as Read

- Batch updates/deletes to solve the "Mark all as Read" problem.
- they act directly on the persistent store, not a context
- need that notification dance to update live contexts

# Most projects aren't a problem.

- Show case of downloading 1 item.
- Show downloading 1000 items. Even all duplicates.
  - Even 1000 duplicate items not much of a big deal.

# Example of project where performance is a problem: Worst case scenario: 5000 items, all duplicates.

- Show Instruments where CPU is working hardcore on main thread

- Use background context to move work out of main thread
  - CPU is still working hard, but main thread is un-blocked

- Instruments to see what's taking the time
  - Show ways we're told to make things nicer:
    - batch saving: overall longer process
    - batch delete everything before processing: more work for the main thread

